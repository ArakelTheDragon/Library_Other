# The task involves writing a code for a Raspberry Pi 4 that operates #indoors.

#The project has two main components:
#- The Raspberry Pi should send an SMS alert through Twilio whenever it #detects a 'clap' sound.
#- Upon receiving a "Y" reply via SMS, it should light up an LED bulb.

# Install the libraries first
# pip install twilio
# sudo apt-get install python3-rpi.gpio if your OS is Ubuntu

import RPi.GPIO as GPIO
import time
from twilio.rest import Client
import sounddevice as sd
import numpy as np

# Twilio setup
account_sid = 'your_account_sid'
auth_token = 'your_auth_token'
twilio_phone_number = 'your_twilio_number'
your_phone_number = 'your_phone_number'

client = Client(account_sid, auth_token)

# GPIO setup
LED_PIN = 18  # Pin where LED is connected
GPIO.setmode(GPIO.BCM)
GPIO.setup(LED_PIN, GPIO.OUT)

# Clap detection setup
clap_threshold = 1000  # Adjust based on sound level from the mic

def detect_clap(indata, frames, time, status):
    volume_norm = np.linalg.norm(indata) * 10
    if int(volume_norm) > clap_threshold:
        send_sms()

def send_sms():
    message = client.messages.create(
        body="Clap detected! Reply 'Y' to turn on the LED.",
        from_=twilio_phone_number,
        to=your_phone_number
    )
    print(f"Sent SMS: {message.sid}")

def check_for_reply():
    messages = client.messages.list(limit=5)
    for msg in messages:
        if msg.body.strip().upper() == 'Y' and msg.direction == 'inbound':
            turn_on_led()

def turn_on_led():
    GPIO.output(LED_PIN, GPIO.HIGH)
    print("LED turned ON")
    time.sleep(10)  # Keep LED on for 10 seconds
    GPIO.output(LED_PIN, GPIO.LOW)
    print("LED turned OFF")

# Main function
def main():
    print("Listening for claps...")
    with sd.InputStream(callback=detect_clap):
        while True:
            check_for_reply()
            time.sleep(1)  # Poll Twilio every second for new messages

try:
    main()
except KeyboardInterrupt:
    print("Exiting...")
finally:
    GPIO.cleanup()

