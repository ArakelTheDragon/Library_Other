import socket
import requests
import os
import getpass

def get_pc_info():
    # Get the PC (host) name
    pc_name = socket.gethostname()
    
    # Get the local IP address
    local_ip = None
    try:
        # Get all network interfaces
        for interface in socket.getaddrinfo(pc_name, None):
            ip_address = interface[4][0]
            if not ip_address.startswith("127."):
                local_ip = ip_address
                break
        if local_ip is None:
            local_ip = "Unable to fetch local IP"
    except Exception as e:
        local_ip = f"Error: {e}"

    # Get the public IP address
    try:
        public_ip = requests.get('https://api.ipify.org').text
    except requests.RequestException:
        public_ip = "Unable to fetch public IP"
    
    # Get the current user account
    try:
        user_account = os.getlogin()
    except OSError:
        user_account = getpass.getuser()

    return {
        "PC Name": pc_name,
        "Local IP Address": local_ip,
        "Public IP Address": public_ip,
        "User Account": user_account
    }

def write_info_to_file(info):
    # Define filename using the user account
    filename = f"{info['User Account']}_info.txt"
    
    with open(filename, 'w') as file:
        for key, value in info.items():
            file.write(f"{key}: {value}\n")
    
    print(f"Information has been recorded in {filename}")

if __name__ == "__main__":
    info = get_pc_info()
    
    print("PC Name:", info["PC Name"])
    print("Local IP Address:", info["Local IP Address"])
    print("Public IP Address:", info["Public IP Address"])
    print("User Account:", info["User Account"])

    write_info_to_file(info)

    # Keep the command prompt open
    input("Press Enter to exit...")
