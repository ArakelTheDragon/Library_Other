function appendToDisplay(value) {
    document.getElementById("display").value += value;
}

function clearDisplay() {
    document.getElementById("display").value = '';
}

function calculateResult() {
    const display = document.getElementById("display");
    try {
        // Handle square root and power expressions
        let expression = display.value
            .replace(/√/g, 'Math.sqrt')  // Replace √ with Math.sqrt
            .replace(/x²/g, '**2')        // Replace x² with exponentiation
            .replace(/x³/g, '**3')        // Replace x³ with exponentiation
            .replace(/1\/x/g, '1/');       // Handle 1/x
        display.value = eval(expression); // Evaluate the expression
    } catch (error) {
        display.value = 'Error'; // Display error if the expression is invalid
    }
}

