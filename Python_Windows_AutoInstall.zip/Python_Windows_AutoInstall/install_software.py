import os
import requests
import subprocess
import time

# List of software to download and their download URLs
software_list = [
    {"name": "7-Zip", "url": "https://www.7-zip.org/a/7z2301-x64.exe", "silent_flags": ["/S"]},
    {
        "name": "LibreOffice", 
        "url": "https://mirror.dkm.cz/tdf/libreoffice/stable/24.8.2/win/x86_64/LibreOffice_24.8.2_Win_x86-64.msi",
        "silent_flags": ["/quiet", "/norestart"]
    },
    {"name": "Notepad++", "url": "https://github.com/notepad-plus-plus/notepad-plus-plus/releases/download/v8.5.6/npp.8.5.6.Installer.x64.exe", "silent_flags": ["/S"]}
]

# Directory to save downloaded installers
download_dir = "C:\\SoftwareInstallers"
if not os.path.exists(download_dir):
    os.makedirs(download_dir)

# Function to download a file
def download_file(url, save_path):
    print(f"Downloading {url} ...")
    response = requests.get(url, stream=True)
    with open(save_path, 'wb') as file:
        for chunk in response.iter_content(chunk_size=1024):
            if chunk:
                file.write(chunk)
    print(f"Downloaded {save_path}")

# Function to run the installer
def run_installer(installer_path, silent_flags):
    print(f"Running installer: {installer_path}")
    try:
        if installer_path.endswith(".msi"):
            # Use msiexec for .msi files
            subprocess.run(["msiexec", "/i", installer_path] + silent_flags, check=True)
        else:
            # Run .exe files directly
            subprocess.run([installer_path] + silent_flags, check=True)
        print(f"Successfully installed {installer_path}")
    except subprocess.CalledProcessError as e:
        print(f"Installation failed: {e}")

# Main process
for software in software_list:
    installer_name = f"{software['name']}_installer.exe" if software['name'] != "LibreOffice" else f"{software['name']}_installer.msi"
    installer_path = os.path.join(download_dir, installer_name)

    # Download the software
    download_file(software['url'], installer_path)

    # Wait for a short period before running the installer
    time.sleep(2)

    # Run the installer with appropriate flags
    if "silent_flags" in software:
        run_installer(installer_path, software["silent_flags"])
    else:
        run_installer(installer_path, [])  # Regular installation

print("All software installed.")
