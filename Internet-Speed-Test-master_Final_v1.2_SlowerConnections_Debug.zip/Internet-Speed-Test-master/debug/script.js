// Changed to an async function to use await inside
document.querySelector('button').addEventListener('click', async (e) => {
    const imageLink = 'https://upload.wikimedia.org/wikipedia/commons/3/3e/Tokyo_Sky_Tree_2012.JPG';
    const downloadSize = 8185374;
    let FinalSpeed = 0; // Initialized FinalSpeed to 0 to fix undefined addition issue

    document.querySelector('.loader-content').classList.add('hide');
    document.querySelector('.loader').classList.remove('hide');

    // Changed while loop to for loop to use async/await for sequential downloads
    for (let j = 0; j < 500; j++) {
        const time_start = new Date().getTime();
        const cacheImg = "?nn=" + time_start;
        const downloadSrc = new Image();

        // Wrapped the onload event in a promise to await image loading
        await new Promise((resolve, reject) => {
            downloadSrc.onload = function() {
                const time_end = new Date().getTime();
                const timeDuration = (time_end - time_start) / 1000;
                const loadedBytes = downloadSize * 8;
                const totalSpeed = (loadedBytes / timeDuration) / 1024 / 1024;
                FinalSpeed += totalSpeed; // Accumulates speed for each download
                resolve(); // Resolve the promise once the image has loaded
            };
            downloadSrc.onerror = reject; // Handle image load errors
            downloadSrc.src = imageLink + cacheImg;
        });
        }
    
        FinalSpeed = (FinalSpeed / 5).toFixed(2); // Averages the speed after all downloads

        document.querySelector('.content').innerHTML = FinalSpeed + '<small>Mbps</small>';
        document.querySelector('.loader-content').classList.remove('hide');
        document.querySelector('.loader-content').classList.add('result');
        document.querySelector('.loader').classList.add('hide');
        document.querySelector('.content').classList.remove('hide');
        e.target.innerText = 'CHECK AGAIN'; // Ready for a new check
    });
